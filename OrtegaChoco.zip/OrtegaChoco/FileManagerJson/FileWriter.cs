﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagerJson
{
    public class FileWriter<T>
    {
        public static FileWriter<T> instance = null;
        

        public FileWriter() { }


        public bool WriteToFile(string FilePath, string Content)
        {
            try
            {
               
                File.WriteAllText(FilePath, Content);
                return true; 
            }
            catch (IOException e)
            {
                return false; 
            }
        }

        public bool FileExist(string FilePath)
        {
            return File.Exists(FilePath); 
        }

        public bool CreateFile(string FilePath)
        {
            try
            { 
                File.Create(FilePath);
                return true; 
            }
            catch (IOException e)
            {
                return false; 
            }
        }

    }
}
