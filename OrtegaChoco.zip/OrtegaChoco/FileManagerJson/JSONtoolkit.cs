﻿
using Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FileManagerJson
{
    public class JSONtoolkit
    {

        public List<Clients> Deserialize(string filepath)
        {
            
            string json = File.ReadAllText(filepath);
            
            return JsonConvert.DeserializeObject<List<Clients>>(json)!;
        }

        public string Serialize(List<Clients> json)
        {
            
            return JsonConvert.SerializeObject(json);
        }

        public List<Admin> DeserializeAdministrator(string filepath)
        {
            
            string json = File.ReadAllText(filepath);
            
            return JsonConvert.DeserializeObject<List<Admin>>(json)!;
        }

        public string SerializeAdministrator(List<Admin> json)
        {
            return JsonConvert.SerializeObject(json);
        }

        public List<Product> DeserializeArticles(string filepath)
        {
            
            string json = File.ReadAllText(filepath);
            
            return JsonConvert.DeserializeObject<List<Product>>(json);
        }

        public string SerializeArticles(List<Product> json)
        {
            
            return JsonConvert.SerializeObject(json);
        }

        public List<BoughtProduct> DeserializeItemsPurchased(string filepath)
        {
            
            string json = File.ReadAllText(filepath);
            
            return JsonConvert.DeserializeObject<List<BoughtProduct>>(json)!;
        }

        public string SerializeItemsPurchased(List<BoughtProduct> json)
        {
            
            return JsonConvert.SerializeObject(json);
        }

    }
}
