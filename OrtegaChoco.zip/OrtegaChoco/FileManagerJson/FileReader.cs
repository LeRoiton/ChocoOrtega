﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagerJson
{
    public class FileReader<T>
    {
        public static FileReader<T> instance = null;
        public FileReader() { }
        public string Read(string filePath)
        {
            string content = File.ReadAllText(filePath);
            return content ;
        }
    }


}
