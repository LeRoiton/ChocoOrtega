﻿
using ChocoShopServices;
using FileManagerJson;
using Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ChocoCore
{
    public class ModelCore
    {
        
        
        public ModelCore() { }
        public Clients AddClient()
        {
            ServiceClients serviceCli = new ServiceClients();
            return serviceCli.CreateClient();
        }

        
        public Product CreateProd()
        {
            ServiceProducts serviceProd = new ServiceProducts();
            return serviceProd.CreateProduct();
        }

        
        public bool CreateDB()
        { 
            ServiceProducts serviceProd= new ServiceProducts();
            bool dbProd = serviceProd.CreateDB();
            return dbProd;
        }

        
        public List<Product> GetAllProducts()
        {
            FileReader<Product> reader = new FileReader<Product>();
            
            var listProduit= reader.Read(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\ChocoData\Data\DBProduct.json");

            return JsonConvert.DeserializeObject<List<Product>>(listProduit);
        }


        public List<Clients> GetAllClients()       
        {
            FileReader<Clients> reader = new FileReader<Clients>();
            
            var listClient= reader.Read(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\Data\DBClient.json");
            return JsonConvert.DeserializeObject<List<Clients>>(listClient);
        }


        public List<Admin> GetAllAdmins()
        {
            FileReader<Admin> reader = new FileReader<Admin>();
            
            var listAdmin= reader.Read(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\Data\DBAdmin.json");
            return JsonConvert.DeserializeObject<List<Admin>>(listAdmin);
        }


        public List<BoughtProduct> GetAllBoughProducts()
        {
            FileReader<BoughtProduct> reader = new FileReader<BoughtProduct>();
            
            var listBoughtProduct = reader.Read(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\Data\DBBoughtProduct.json");
            return JsonConvert.DeserializeObject<List<BoughtProduct>>(listBoughtProduct);
        }


        public float CalculateSumOrder(List<BoughtProduct> boughtList)
        {
            float price = 0;
            if (boughtList.Count == 0)
            {
                
                return price;
            }

            
            foreach (BoughtProduct b in boughtList)
            {
               
                foreach (Product p in DataBase.GetInstance().products)
                {
                    
                    if (b.idProduct == p.Id)
                    {
                        price += p.Price * b.Quantity;
                    }
                }
            }

            return price;
        }

       
        public bool ShowProduct(List<Product> products)
        {
            if (products.Count == 0)
            {
                
                return false;
            }

            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine(i + 1 + "The total price is [" + products[i].Reference + " ; " + products[i].Price + "€ ]");
            }

            return true;
        }

        
        public bool ShowClient(List<Clients> clients)
        {
            if (clients == null || clients.Count == 0)
            {
                
                return false;
            }

            foreach (var c in clients)
            {
                Console.WriteLine(c);
            }

            return true;
        }

        
        public bool ShowAdmins(List<Admin> admins)
        {
            if (admins.Count == 0)
            {
               
                return false;
            }

            foreach (var a in admins)
            {
                Console.WriteLine(a);
            }

            return true;
        }
    }
}
