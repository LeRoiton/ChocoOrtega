﻿
using ChocoCore;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Formats.Asn1;
using FileManagerJson;
using Model;

namespace ChocoCore
{
    public class FileCore
    {

        public FileCore()
        {
            if (!Directory.Exists("./Data/Bill"))
            {
                Directory.CreateDirectory("./Data/Bill");
            }
            if (!Directory.Exists("./Data/PastOrder"))
            {
                Directory.CreateDirectory("./Data/PastOrder");
            }
        }


        public bool ClientOrder(string filepath, Clients client, List<BoughtProduct> boughtProducts)
        {
            File.AppendAllText(filepath, client.Lastname + " " + client.Firstname + "\nAdress : " + client.Adress + "\nPhone number : " + client.Phone + "\n");
            File.AppendAllText(filepath, "\n\nProducts : \n");


            foreach (BoughtProduct bp in boughtProducts)
            {

                foreach (Product product in DataBase.GetInstance().products)
                {

                    if (bp.IdProduct == product.Id)
                    {

                        File.AppendAllText(filepath, "\t* " + product.Reference + " : " + product.Price + "€ x " + bp.Quantity + " = " + product.Price * bp.Quantity + "€\n");
                    }
                }
            }

            File.AppendAllText(filepath, "Total : " + "€\n");
            File.AppendAllText(filepath, "\nDate : " + DateTime.Now.ToString("dd-MM-yyyy HH-mm-ss"));
            return true;

        }

        public bool AddProduct()
        {
            Console.WriteLine("Add a new product");
            FileWriter<Product> wr = new FileWriter<Product>();
            Console.WriteLine("Product added.");
            return true;
        }

        public bool CreateNewBill()
        {
            Console.WriteLine("New Bill created");
            
            
            string fileName = @"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\Data\Bill\" + DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") + "_bill.txt";
            
            File.Create(fileName).Close();
          
            List<BoughtProduct> boughtProducts = DataBase.GetInstance().boughtProducts;
            
            List<Product> products = DataBase.GetInstance().products;
            
            if (boughtProducts.Count == 0)
            {
                
                return false;
            }
            
            foreach (BoughtProduct bp in boughtProducts)
            {
                int qty = 0;
                Product p = products.Find(x => x.Id == bp.IdProduct);
                if (p == null)
                {
                    
                    return false;
                }
                qty += bp.Quantity;
                
                File.AppendAllText(fileName, p.Reference + " : " + p.Price + "€ x " + qty + " = " + p.Price * qty + "€\n");
            }
            return true;
        }


        public bool NewBillByClient()
        {
            Console.WriteLine("New bill with the total spent by a client");
            
            string fileName = "./Data/Bill/" + DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") + "_BillByClient.txt";
            
            File.Create(fileName).Close();
            
            List<BoughtProduct> bProds = DataBase.GetInstance().boughtProducts;
            
            List<Clients> clients = DataBase.GetInstance().clients;
            
            Dictionary<Clients, List<BoughtProduct>> dico = new Dictionary<Clients, List<BoughtProduct>>();
            foreach (BoughtProduct bp in bProds)
            {
                Clients c = clients.Find(x => x.Id == bp.IdClient);
                if (dico.ContainsKey(c))
                {
                    dico[c].Add(bp);
                }
                else
                {
                    dico.Add(c, new List<BoughtProduct>());
                    dico[c].Add(bp);
                }
            }
            
            foreach (KeyValuePair<Clients, List<BoughtProduct>> client in dico)
            {
                this.ClientOrder(fileName, client.Key, client.Value);
                File.AppendAllText(fileName, "\n\n");
            }

            return true;
        }


        public bool NewBillByDate()
        {
            Console.WriteLine("New Bill showing the order by date");
            string fileName = "./Data/Bill/" + DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") + "_billByDate.txt";
            File.Create(fileName).Close();
            List<BoughtProduct> bProds = DataBase.GetInstance().boughtProducts;
            Dictionary<string, List<BoughtProduct>> dico = new Dictionary<string, List<BoughtProduct>>();
            foreach (BoughtProduct bp in bProds)
            {
                string str = bp.DatePurchase.ToString("dd-MM-yyyy");
                if (dico.ContainsKey(str))
                {
                    dico[str].Add(bp);
                }
                else
                {
                    dico.Add(str, new List<BoughtProduct>());
                    dico[str].Add(bp);
                }
            }
            foreach (KeyValuePair<string, List<BoughtProduct>> date in dico)
            {
                File.AppendAllText(fileName, "Date : " + date.Key + "\n");
                foreach (BoughtProduct bp in date.Value)
                {
                    foreach (Product product in DataBase.GetInstance().products)
                    {
                        if (bp.IdProduct == product.Id)
                        {
                            File.AppendAllText(fileName, "\t* " + product.Reference + " : " + product.Price + "€ x " + bp.Quantity + " = " + product.Price * bp.Quantity + "€\n");
                        }
                    }
                }
                
                File.AppendAllText(fileName, "\n\n");
            }
            return true;
        }




    }
}

