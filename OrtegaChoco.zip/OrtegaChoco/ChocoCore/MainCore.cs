﻿
using ChocoCore;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileManagerJson;
using Model;
using Newtonsoft.Json;

namespace ChocoCore
{
    public class MainCore
    {
        public char ChoixProfil()
        {
            Console.WriteLine("Who are you ? : \t1:Admin  \t2: Client");

            bool choiceMade = false;
            char choice = '0';
            Console.WriteLine("You choose : ");
            do
            {
                    choice = Console.ReadKey().KeyChar;
                    Console.WriteLine();
                    if (choice == '1' || choice == '2')
                    {
                        choiceMade = true;
                    }
                    else
                    {
                        Console.WriteLine("Invalid number");

                    }
                
            } while (!choiceMade);


            return choice;
        }
            private string GetClientInput(string prompt)
        {
            string input;
            Console.WriteLine(prompt);
            input = Console.ReadLine();
            return input;
        }

        
        public Clients GetInfoClient()
        {
            
            Console.WriteLine("Please give us your informations");
            Clients c = new Clients();

           c.Lastname = GetClientInput("What is your lastname ? ");
           c.Firstname = GetClientInput("What is your firstname ? ");
           c.Adress = GetClientInput("What is your adress ? ");
           c.Phone = GetClientInput("What is your phone number ? ");

            Console.WriteLine();

            
            return SignInClient(c);
        }

        public Clients SignInClient(Clients c)
        {
            
            foreach (var a in DataBase.GetInstance().clients)
            {
                if (c.Equals(a))
                {
                    c.Id = a.Id;
                    return c;
                }
            }

            
            FileWriter<Clients> wr = new FileWriter<Clients>();
             string fileName = @"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\ChocoData\Data\clients.json";
                string jsonString = JsonConvert.SerializeObject(c);
                File.WriteAllText(fileName, jsonString);
            
            wr.WriteToFile(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\ChocoData\Data\clients.json", c.ToString());
            
            return c;
        }

        public bool ProgramClient()
        {
            
           Clients client = this.GetInfoClient();
           
            Console.WriteLine("Welcome, " + client.Firstname + " " + client.Lastname);
            
            this.Order(client);
            return true;
        }
        public bool LaunchOrder()
        {

            Clients c = this.GetInfoClient();
            
            Console.WriteLine("Welcome to our shop, " + c.Firstname + " " + c.Lastname);
            
            this.Order(c);
            return true;
        }

        public bool Order(Clients c)
        {
            Console.WriteLine("Choose your product, and the quantity.");
            List<BoughtProduct> bp = new List<BoughtProduct>();
            bool notFinished = true;
            ModelCore mc = new ModelCore();
            do
            {
                mc.ShowProduct(DataBase.GetInstance().products);
                Console.WriteLine("F : End the order");
                Console.WriteLine("P : Show the current price of your check out");
                Console.WriteLine("What do you want do to ? : ");

                notFinished = this.ProductOrder(c, bp);
                Console.WriteLine();
            } while (notFinished);

            string fileName = c.Lastname + "-" + c.Firstname + "-" + DateTime.Now.ToString("dd-MM-yyyy-HH-mm") + ".txt";
            return true;
        }



        public bool ProductOrder(Clients c, List<BoughtProduct> bP)
        {
            char choice = ChoiceReader();
            Console.WriteLine();

            if (choice == 'F')
            {
                Console.WriteLine("Thank you for ordering on our shop !");
                return false;
            }

            if (choice == 'P')
            {
                Console.WriteLine("The current check out of your order is : ", ShowSumOrder(bP));
                return true;
            }

            if (ChoiceProduct(choice))
            {
                int quantity = SelectQuantity(choice);
                AddBoughtProducts(c, bP, choice, quantity);
                return true;
            }

            return true;
        }

        public bool AdminConnect()
        {
            Console.WriteLine("Insert Login and Password please");
            
            DataBase db = DataBase.GetInstance();
            string login = "";
            bool signIn = false;
            bool password = false;
            int tries = 0;
            do
            {
                if (!password)
                    {
                        
                        Console.WriteLine(tries > 0 ? "Incorrect Password" : "Mot de passe : ");
                        string passwordIn = Console.ReadLine();
                       
                        password = db.admins.Exists(x => x.Password == passwordIn);
                    }
                 if (!signIn)
                    {
                        
                        Console.WriteLine(tries > 0 ? "Login incorrect" : "Login : ");
                        login = Console.ReadLine();
                        
                        signIn = db.admins.Exists(x => x.Login == login);
                    }
                

                tries++;
            } while (!(signIn && password));

            
            Console.WriteLine("Welcome, " + login + " !");
            return true;
        }

        
        public char AdminChoice()
        {
            
            Console.WriteLine("1 = New Product");
            Console.WriteLine("2 = Delete Product");
            Console.WriteLine("3 =  Close the console.");
            bool choiceMade = false;
            char choice = '0';

            do
            {
                Console.WriteLine("Your choice : ");
                choice = Console.ReadKey().KeyChar;
                Console.WriteLine();
                if (choice == '1' || choice == '2' || choice == '3')
                {
                    choiceMade = true;
                }
                else
                {
                    Console.WriteLine("Number not valid");
                    
                }
            } while (!choiceMade);

            
            return choice;
        }

        public bool ProgramAdmin()
        {
             
            FileCore fileCore = new FileCore();
            
            Console.WriteLine("Bienvenue dans le profil administrateur");
            this.AdminConnect();
            bool keepGoing = true;
            do
            {
                switch (this.AdminChoice())
                {
                    case '1':
                        fileCore.AddProduct();
                        break;
                    case '2':

                        fileCore.CreateNewBill();
                        break;
                    case '3':

                        fileCore.NewBillByClient();
                        break;
                    case '4':

                        fileCore.NewBillByDate();
                        break;
                    case '5':
                        
                        Console.WriteLine("Cya");
                        keepGoing = false;
                        return false;
                        break;
                    default:
                        Console.WriteLine("Error");
                        keepGoing = false;
                        break;
                }
                Console.WriteLine();
            } while (keepGoing);

            return true;
        }
        private char ChoiceReader()
        {
            return Console.ReadKey().KeyChar;
        }

        private float ShowSumOrder(List<BoughtProduct> bP)
        {
            ModelCore mC = new ModelCore();
            float price = mC.CalculateSumOrder(bP);
            return price;
            
        }

        private bool ChoiceProduct(char choice)
        {
             DataBase db = DataBase.GetInstance();
            int choiceInt = int.Parse(choice.ToString());
            if (choiceInt <= 0 || choiceInt > db.products.Count)
            {
                Console.WriteLine("Not a valid number");
            }
            return true;
        }

        private int SelectQuantity(int quantity)
        {
            Console.WriteLine("Select the quantity");
            if (quantity <= 0)
            {
                Console.WriteLine("Not a valid quantity");
            }

            return quantity;
        }

        private void AddBoughtProducts(Clients c, List<BoughtProduct> bp, char choice,
            int quantity)
        {
            int choiceInt = int.Parse(choice.ToString());
            Product p = DataBase.GetInstance().products[choiceInt - 1];

            BoughtProduct boughtProduct = new BoughtProduct
            {
                IdProduct = p.Id,
                IdClient = c.Id,
                Quantity = quantity
            };

            DataBase.GetInstance().boughtProducts.Add(boughtProduct);
            bp.Add(boughtProduct);

            FileWriter<BoughtProduct> wr = new FileWriter<BoughtProduct>();
            wr.WriteToFile(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\Data", boughtProduct.ToString());

            
        }


        
        

        
        

    }
}
