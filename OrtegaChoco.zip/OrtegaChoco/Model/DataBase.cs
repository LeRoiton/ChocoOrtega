﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class DataBase
    {

        private static DataBase instance;

        public char profil;
        public List<Clients> clients;
        public List<Product> products;
        public List<BoughtProduct> boughtProducts;
        public List<Admin> admins;
        

        
        public static DataBase GetInstance()
        { return instance;}

    }
}
