﻿using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Admin
    {
        private Guid id;
        private string login;
        private string password;

        public Admin()
        {
            
            Id = Guid.NewGuid();
        }

        public Admin(string login, string password)
        {
            Id = Guid.NewGuid();
            Login = login;
            Password = password;
        }

        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Login
        {
            get { return login; }
            set
            {
                
                login = value;
            }
        }

        static bool IsSpecialCharacter(char c)
        {
            string caractèresSpeciaux = "()*!$%@#^&[]{}'¤£§";
            return caractèresSpeciaux.Contains(c);
        }
        public string Password
        {
            get { return password; }
            set
            {
                    if (value == null || value.Trim().Equals(""))
                    {
                        // Si le mot de passe est null ou vide
                        throw new Exception("Error");
                    }

                    if (value.Length < 6)
                    {
                        // Si le mot de passe est inférieur à 6 caractères
                        throw new Exception("Password too short");
                    }

                    if (!value.Any(c => IsSpecialCharacter(c)))
                    {
                        // Si le mot de passe ne contient pas de chiffre
                        throw new Exception("Password needs at least one special key");
                    }
                    password = value;
                
            }
        }


        public override string ToString()
        {
            return "Id : " + id + ", Login : " + login + " and Password : " + password;
        }

    }
}
