﻿using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class BoughtProduct
    {

        
        private Guid idClient;
        public Guid idProduct;
        private int quantity;
        private DateTime datePurchase;

        public BoughtProduct()
        {
            
            DatePurchase = DateTime.Now;
        }

        public BoughtProduct(Guid idClient, Guid idProduc, int quantity)
        {
            IdClient = idClient;
            IdProduct = idProduct;
            Quantity = quantity;
            DatePurchase = DateTime.Now;
        }

        public Guid IdClient
        {
            get { return idClient; }
            set { idClient = value; }
        }

        public Guid IdProduct
        {
            get { return idProduct; }
            set { idProduct = value; }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                
               quantity = value;
            }
        }


        public DateTime DatePurchase
        {
            get { return datePurchase; }
            set
            {
               
                datePurchase = value;
            }
        }

        public override string ToString()
        {
            return "IdClient : " + IdClient + " ; IdProduct : " + IdProduct + " ; Quantity : " + Quantity + " ; DateAchat : " + DatePurchase;
        }

    }
}
