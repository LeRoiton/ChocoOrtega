﻿using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Product
    {

        private Guid id;
        private string reference;
        private float price;

        public Product()
        {
            
            Id = Guid.NewGuid();
        }

        public Product(string reference, float price)
        {
            Id = Guid.NewGuid();
            Reference = reference;
            Price = price;
        }

        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Reference
        {
            get { return reference; }
            set
            {
                
                reference = value;
            }
        }

        public float Price
        {
            get { return price; }
            set
            {
                
                price = value;
            }
        }

        public override string ToString()
        {
            return "Id : " + Id + " Reference : " + reference + " value : " + price;
        }

    }
}
