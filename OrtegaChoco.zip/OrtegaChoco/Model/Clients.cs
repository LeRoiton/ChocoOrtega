﻿using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Clients
    {
        private Guid id;
        private string lastname;
        private string firstname;
        private string adress;
        private string phone;

        public Clients()
        {
           
            id = Guid.NewGuid();
        }
        public Clients(string lastname, string firstname, string adress, string phone)
        {
            id = Guid.NewGuid();
            Lastname = lastname;
            Firstname = firstname;
            Adress = adress;
            Phone = phone;
        }

        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Lastname
        {
            get { return lastname; }
            set
            {
                lastname = value;
            }
        }

        public string Firstname
        {
            get { return firstname; }
            set
            {
                
                firstname = value;
            }
        }


        public string Adress
        {
            get { return adress; }
            set
            {
               
                adress = value;
            }
        }

        public string Phone
        {
            get { return phone; }
            set
            {
               
                phone = value;
            }
        }

        public override string ToString()
        {
            return $"Id: {id}, Lastname: {Lastname}, Firstname: {Firstname}, Adress: {Adress}, Phone: {Phone}";
        }


    }
}
