﻿
using FileManagerJson;
using Model;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChocoShopServices
{
    public class ServiceAdmin
    {

        public Admin CreateAdmin()
        {
            Console.WriteLine("Enter a login and a password");
            Admin admin = new Admin();
            bool login = false;
            bool password = false;
            do
            {
                    if (!login)
                    {
                        Console.WriteLine("Login : ");
                        admin.Login = Console.ReadLine();
                        login = true;
                    }
                    if (!password)
                    {
                        Console.WriteLine("Password : ");
                        admin.Password = Console.ReadLine();
                        password = true;
                    }
                
            } while (!(login && password));
            return admin;
        }

        public bool CreateDB()
        {
            FileWriter<Admin> wr = new FileWriter<Admin>();
            if (!wr.FileExist(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\ChocoData\Data"))
            {
              Console.WriteLine("New admin create");
               Admin admin = new Admin("admin", "admin1");
              wr.WriteToFile(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\ChocoData\Data", admin.ToString());
               return true;
            }
            Console.WriteLine("Admin already created");
            return false;
        }
    }
}
