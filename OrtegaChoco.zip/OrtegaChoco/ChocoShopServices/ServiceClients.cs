﻿using Model;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ChocoShopServices
{
    public class ServiceClients
    {
        public Clients CreateClient()
        {
            Clients client = new Clients();
            bool lastname = false;
            bool firstname = false;
            bool adress = false;
            bool phone = false;

            Console.WriteLine("Please enter your personal informations");
            do
            {
                try
                {
                    if (!lastname)
                    {
                        Console.WriteLine("What is your last name ? :");
                        client.Lastname = Console.ReadLine();
                        lastname = true;

                    }
                    if (!firstname)
                    {
                        Console.WriteLine("What is your firstname ? :");
                        client.Firstname = Console.ReadLine();
                        firstname = true;
                    }
                    if (!adress)
                    {
                        Console.WriteLine("What is your adress ? :");
                        client.Adress = Console.ReadLine();
                        adress = true;
                    }
                    if (!phone)
                    {
                        Console.WriteLine("What is your phone number ? :");
                        client.Phone = Console.ReadLine();
                        phone = true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            } while (!(phone && adress && lastname && firstname));
           
            return client;
        }
    }
}
