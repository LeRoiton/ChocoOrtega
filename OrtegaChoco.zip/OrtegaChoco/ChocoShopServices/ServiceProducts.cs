﻿
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileManagerJson;
using Model;
using Newtonsoft.Json;

namespace ChocoShopServices
{
    public class ServiceProducts
    {
        public Product CreateProduct()
        {
            Product product = new Product();

            Console.WriteLine("Add a new product to the shop !");

            bool reference = false;
            bool price = false;
            do
            {
                try
                {
                    if (!reference)
                    {
                        Console.WriteLine("New product's reference :");
                        product.Reference = Console.ReadLine();
                        reference = true;
                    }
                    if (!price)
                    {
                        Console.WriteLine("New product's price");
                        float p = float.Parse(Console.ReadLine());
                        product.Price = p;
                        price = true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            } while (!(reference && price));
            return product;
        }

        public bool CreateDB()
        {
            FileWriter<Product> wr = new FileWriter<Product>();
            if (!wr.FileExist(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\ChocoData\Data\DBProduct.json"))
            {
               
                Console.WriteLine("Available products : ");
                List<Product> products = new List<Product>();
                products.Add(new Product("White chocolate", 4.5f));
                products.Add(new Product("Dark Chocolate extra", 3.35f));
                products.Add(new Product("Dark Chocolate", 4.55f));
                var prodJson = JsonConvert.SerializeObject(products);
                foreach (var p in products)
                {
                    wr.WriteToFile(@"C:\Users\flori\OneDrive\Bureau\Cours ESI\C#\OrtegaChoco\OrtegaChoco\ChocoData\Data\DBProduct.json", p.ToString());
                }
                return true;}
            return false;
        }
    }
}
