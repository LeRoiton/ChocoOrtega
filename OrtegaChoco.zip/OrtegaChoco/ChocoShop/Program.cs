﻿
using ChocoCore;
using Model;

public class Program { 
public static void Main(string[] args)
{
        mainProgram();


}

    public static void mainProgram()
    {

        DataBase db = DataBase.GetInstance();


        
            ModelCore models = new ModelCore(); 

            MainCore mainCore = new MainCore(); 
            
            
            Console.Clear();

            
        models.CreateDB();

            
            db.products = models.GetAllProducts();

            
            db.admins = models.GetAllAdmins();

            
            db.clients = models.GetAllClients();

            
            db.boughtProducts = models.GetAllBoughProducts();


            Console.WriteLine("Welcome in our online shop !");

            
            db.profil = mainCore.ChoixProfil();

            
            if (DataBase.GetInstance().profil == '1')
            {
                mainCore.ProgramAdmin();
            }
            else if (DataBase.GetInstance().profil == '2')
            {
                mainCore.ProgramClient();
            }
        }
        
    

}


